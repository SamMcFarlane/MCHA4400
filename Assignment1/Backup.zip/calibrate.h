#ifndef CALIBRATE_H
#define CALIBRATE_H

#include <filesystem>

void calibrateCamera(const std::filesystem::path & configPath);

#endif